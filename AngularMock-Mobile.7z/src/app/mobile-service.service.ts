import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MobileServiceService {
  http:HttpClient;
 mobiles:Mobile[]=[];
  constructor(http:HttpClient) {
    this.http=http;
   }
   fetched:boolean=false;
   fetchMobiles()
   {
     this.http.get('./assets/mobile.json')
     .subscribe(
       data=>{
         if(!this.fetched)
         {
           this.convert(data);
           this.fetched=true;
         }
       }
     );
     }
     getMobiles():Mobile[]{
      return this.mobiles;
    }
    convert(data:any)
    {
      for(let o of data)
      {
        let m=new Mobile(o.mobId,o.mobName,o.mobPrice);
        this.mobiles.push(m);
      }
    }
    delete(mobId:number)
    {
      let foundIndex:number=-1;
      for(let i=0;i<this.mobiles.length;i++)
      {
        let m=this.mobiles[i];
        if(mobId==m.mobId)
        {
          foundIndex=i;
          break;
        }
      }
      this.mobiles.splice(foundIndex,1);
    }
   

}
  export class Mobile
  {
   mobId:number;
   mobName:string;
   mobPrice:DoubleRange;
   constructor(mobId:number,mobName:string,mobPrice) {
     this.mobId=mobId;
     this.mobName=mobName;
     this.mobPrice=mobPrice;
  }
 
}
