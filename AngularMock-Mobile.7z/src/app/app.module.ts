import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';

import { MobileServiceService } from './mobile-service.service';
import { HttpClientModule, HttpClient } from '../../node_modules/@angular/common/http';
import { OrderByPipe } from './order-by.pipe';

@NgModule({
  declarations: [
    AppComponent,
    OrderByPipe,
  
  ],
  imports: [
    BrowserModule,
   HttpClientModule
  ],
  providers: [ MobileServiceService,HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
