import { Component, OnInit} from '@angular/core';
import { MobileServiceService, Mobile } from './mobile-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  service:MobileServiceService
  constructor(service:MobileServiceService) {
    this.service=service;
   }
  mobiles:Mobile[]=[]

  ngOnInit() {
    this.service.fetchMobiles();
    this.mobiles=this.service.getMobiles();
  }
delete(mobId:number)
{
  this.service.delete(mobId);
}
column:string="mobId";
order:boolean=true;
sort(column:string)
{
  if(this.column==column)
  {
    this.order=!this.order;
  }
  else
  {
    this.order=true;
    this.column=column;
  }
}
}
