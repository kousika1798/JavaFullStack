import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { ListAllEmployeesComponent } from './list-all-employees/list-all-employees.component';
import { EmployeeRouterModule } from './employee-router/employee-router.module';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule} from '@angular/common/http';
import { EmployeeServiceService } from './employee-service.service';

@NgModule({
  declarations: [
    AppComponent,
    AddEmployeeComponent,
    ListAllEmployeesComponent
  ],
  imports: [
    BrowserModule,
    EmployeeRouterModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [HttpClient,EmployeeServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
