import { Component, OnInit } from '@angular/core';
import { EmployeeServiceService, Employee } from '../employee-service.service';

@Component({
  selector: 'app-list-all-employees',
  templateUrl: './list-all-employees.component.html',
  styleUrls: ['./list-all-employees.component.css']
})
export class ListAllEmployeesComponent implements OnInit {

  service:EmployeeServiceService;         //service object is created for EmployeeService   
  
  constructor(service:EmployeeServiceService) {
    this.service=service;
   }
   employees:Employee[]=[];

  ngOnInit() {
    this.service.fetchEmployees();
    this.employees=this.service.getEmployees();
  }
delete(eid:number)          
{
  this.service.delete(eid);
}
}
