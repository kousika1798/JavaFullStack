import { EmployeeRouterModule } from './employee-router.module';

describe('EmployeeRouterModule', () => {
  let employeeRouterModule: EmployeeRouterModule;

  beforeEach(() => {
    employeeRouterModule = new EmployeeRouterModule();
  });

  it('should create an instance', () => {
    expect(employeeRouterModule).toBeTruthy();
  });
});
