import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule,Routes } from '@angular/router';
import { AddEmployeeComponent } from '../add-employee/add-employee.component';
import { ListAllEmployeesComponent } from '../list-all-employees/list-all-employees.component';

const routes:Routes=[
 {
   path:'', 
   pathMatch:'full',
   component:ListAllEmployeesComponent
 },
  {
    path:'add-Employee',

  component:AddEmployeeComponent,
  
  },          
  
  {
    path:'list-Employee',

  component: ListAllEmployeesComponent
  }
]
@NgModule({
  imports: [RouterModule.forRoot(routes),
    CommonModule
  ],
  exports:[RouterModule]
})
export class EmployeeRouterModule { }
