import { Component, OnInit } from '@angular/core';
import { Employee, EmployeeServiceService } from '../employee-service.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  createdEmployee:Employee;
  router:Router;
  flag:boolean=false;
  service:EmployeeServiceService;
  constructor(service:EmployeeServiceService,router:Router) {
    this.service=service;
    this.router=router;
   }

  ngOnInit() {
  }
add(data:any)
{
  this.createdEmployee=new Employee(data.eid,data.ename,data.email,data.phone);
  this.service.add(this.createdEmployee);
  this.router.navigate(['/list-Employee']);
}


}
