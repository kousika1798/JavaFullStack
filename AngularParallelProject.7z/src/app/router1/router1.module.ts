import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule,Routes } from '@angular/router';
import { CreateAccountComponent } from '../create-account/create-account.component';
import { ShowBalanceComponent } from '../show-balance/show-balance.component';
import { DepositComponent } from '../deposit/deposit.component';
import { WithdrawComponent } from '../withdraw/withdraw.component';
import { FundTransferComponent } from '../fund-transfer/fund-transfer.component';
import { PrintTransactionComponent } from '../print-transaction/print-transaction.component';

const routes:Routes=[
  {
    path:'create-account',
    component:CreateAccountComponent
  },
  {
    path:'show-balance',
    component:ShowBalanceComponent
  },
  {
    path:'deposit',
    component:DepositComponent
  },
  {
    path:'withdraw',
    component:WithdrawComponent
  },
  {
    path:'fund-transfer',
    component:FundTransferComponent
  },
  {
    path:'print-transaction',
    component:PrintTransactionComponent
  }
]


@NgModule({
  imports: [RouterModule.forRoot(routes),
    CommonModule
  ],
  exports:[RouterModule]
})
export class Router1Module { }
