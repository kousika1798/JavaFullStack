import { Router1Module } from './router1.module';

describe('Router1Module', () => {
  let router1Module: Router1Module;

  beforeEach(() => {
    router1Module = new Router1Module();
  });

  it('should create an instance', () => {
    expect(router1Module).toBeTruthy();
  });
});
