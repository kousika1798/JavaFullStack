package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {
	AccountDao accountDao=new AccountDaoImpl();

	@Override
	public Account getAccountDetails(String mobileNo) {
		
		
		return accountDao.getAccountDetails(mobileNo);
		
	}

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount) {
		
		return accountDao.rechargeAccount(mobileNo, rechargeAmount);
	}

	@Override
	public Boolean numberValidation(String number) {
		if(number.matches("[6-9][0-9]{9}"))
		return true;
		else
			return false;
	}

	@Override
	public Boolean amountValidation(Double amount) {
		if(amount<=0)
		{
			return false;
		}
		else
		{
		return true;
		}
	}

}
