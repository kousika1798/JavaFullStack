package com.cg.mra.ui;

import java.util.Scanner;


import com.cg.mra.exceptions.NumberNotFoundExceptions;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		 Scanner scan=new Scanner(System.in);
		
		AccountService  accountService=new AccountServiceImpl();
		
		while(true)
		{
			System.out.println("    Mobile Recharge Application   ");
			System.out.println("1) Account Balance Enquiry");
			System.out.println("2) Recharge Account");
			System.out.println("3) Exit");
			System.out.println("Enter your choice");
			int option=scan.nextInt();
			switch(option)
			{
			case 1:
				String mobileNumber;
				Boolean isNumber;
				do
				{
					System.out.println("Enter Mobile No: ");
					mobileNumber=scan.next();
				isNumber=accountService.numberValidation(mobileNumber);
				
				if(!isNumber)
				{
					System.out.println("Enter the valid number");
				}
				
				}while(!isNumber);
				
				try
				{
				
				System.out.println("Your Current Balance is Rs. "+accountService.getAccountDetails(mobileNumber));
				
				}
				catch(NumberNotFoundExceptions ne)
				{
					System.out.println(ne.getMessage());
				}
				break;
				
			case 2:
				String mobileNumber2;
				Boolean isNumber1;
				do
				{
					System.out.println("Enter Mobile No: ");
					mobileNumber2=scan.next();
				isNumber1=accountService.numberValidation(mobileNumber2);
				if(!isNumber1)
				{
					System.out.println("Enter the valid number");
				}
				}while(!isNumber1);
				
				double amount;
				Boolean isAmount;
				do
				{
				System.out.println("Enter Recharge Amount: ");
				amount=scan.nextDouble();
				isAmount=accountService.amountValidation(amount);
				if(!isAmount)
				{
					System.out.println("Enter Valid Amount");
				}
				}while(!isAmount);
				
				try
				{
				
				
				System.out.println("Your Account Recharged Successfully");
				System.out.println("Hello"+"Available Balance is"+accountService.rechargeAccount(mobileNumber2, amount));
				}
				catch(NumberNotFoundExceptions ne)
				{
					System.out.println(ne.getMessage());
				}
				break;
				
			case 3:
				System.exit(0);
			}
		}
	}

}
