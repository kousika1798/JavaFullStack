package com.cg.mra.exceptions;

public class NumberNotFoundExceptions extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NumberNotFoundExceptions(String message) {
		super(message);
		
	}

	
	}


