"use strict";
exports.__esModule = true;
var inheritance_1 = require("./inheritance");
var c = new inheritance_1.cl1("kousika", "rangaraj");
var result1 = c.fname + " " + c.lname;
console.log(result1);
var c1 = new inheritance_1.cl2(1002, "kousika", "rangaraj");
c1.showdetails();
