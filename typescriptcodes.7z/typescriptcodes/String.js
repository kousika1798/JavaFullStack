var fname = "IBM";
var site = 'www.ibm.com';
var string1 = "Hello my name is " + fname + "site is " + site;
console.log(string1);
var string2 = "my name is " + fname + " and site is " + site + " ";
console.log(string2);
