export class cl1
{
    fname:string;
    lname:string;
    constructor(fname:string,lname:string)
    {
        this.fname=fname;
        this.lname=lname;
    }

}
export class cl2 
{
id:number;
fname:string;
lname:string
constructor(id:number,fname:string,lname:string)
{
this.id=id;
this.fname=fname;
this.lname=lname;
}
showdetails():void
{
    console.log(this.id+" "+this.fname+" "+this.lname);
}
}

