class cl1
{
    fname:string;
    lname:string;

}
var c=new cl1();
c.fname="kousi";
c.lname="ragul";
console.log(c.fname+" "+c.lname);