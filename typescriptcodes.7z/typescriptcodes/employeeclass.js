var emp = /** @class */ (function () {
    function emp(empid, name) {
        emp.empid = empid;
        this.name = name;
    }
    emp.prototype.displayDetails = function () {
        return emp.empid + " " + this.name;
    };
    return emp;
}());
emp.empid = 14002;
console.log(emp.empid);
var e = new emp(1002, "kousi");
console.log(e.displayDetails());
