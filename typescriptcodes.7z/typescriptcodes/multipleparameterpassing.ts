function add(x:number,...y:number[]):number
{
    let result=x;
    for(var i=0;i<y.length;i++)
    {
        result+=y[i];
    }
    return result;

}
let result1=add(5,2,6,8,4,5);
let result2=add(2,4);
console.log(result1+" "+result2);