let num=12;
let a1=[1,2,3,'a',true];
var x:number[];
x=[1,2,3,4,5];
x.push(10);
console.log(x);
num=x.pop();
let list:number[]=[1,2,3,4];
let list1:Array<number>=[1,2,3,4];
console.log(list);


console.log(num);

