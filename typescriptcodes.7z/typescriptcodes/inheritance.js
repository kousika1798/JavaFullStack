"use strict";
exports.__esModule = true;
var cl1 = /** @class */ (function () {
    function cl1(fname, lname) {
        this.fname = fname;
        this.lname = lname;
    }
    return cl1;
}());
exports.cl1 = cl1;
var cl2 = /** @class */ (function () {
    function cl2(id, fname, lname) {
        this.id = id;
        this.fname = fname;
        this.lname = lname;
    }
    cl2.prototype.showdetails = function () {
        console.log(this.id + " " + this.fname + " " + this.lname);
    };
    return cl2;
}());
exports.cl2 = cl2;
