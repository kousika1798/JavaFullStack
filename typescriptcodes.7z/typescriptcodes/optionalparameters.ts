function add(a:number,b:number,c?)
{
    return a+b+c;
}
var sum1=add(2,5,7);
var sum2=add(5,8);
var sum3=add(6,7,"hii");
function add1(x,y,z,u?:number)
{
    return x+y+z+u;
}
var sum4=add1(6,7,"hii",6);
var sum5=add1(6,7,"hii");
function add2(x,y,z,u?:number):number
{
    return x+y+z+u;
}
var sum6=add2(6,7,"hii",6);
var sum7=add2(6,7,6);
console.log(sum1);
console.log(sum2);
console.log(sum3);
console.log(sum4);
console.log(sum5);
console.log(sum6);
console.log(sum7);