var cl1 = /** @class */ (function () {
    function cl1() {
    }
    return cl1;
}());
var c = new cl1();
c.fname = "kousi";
c.lname = "ragul";
console.log(c.fname + " " + c.lname);
