class emp
{
    static empid:number;
    
    name:string;
    constructor(empid:number,name:string)
    {
        emp.empid=empid;
        this.name=name;
    }
    displayDetails()
    {
        return emp.empid+" "+this.name; 
    }

}
emp.empid=14002;
console.log(emp.empid);
var e =new emp(1002,"kousi");
console.log(e.displayDetails());