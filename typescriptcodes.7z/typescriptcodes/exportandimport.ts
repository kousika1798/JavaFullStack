import{cl1,cl2} from "./inheritance";
let c=new cl1("kousika","rangaraj");
let result1=c.fname+" "+c.lname;
console.log(result1);
let c1=new cl2(1002,"kousika","rangaraj");
c1.showdetails();