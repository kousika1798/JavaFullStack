function add(x, y) {
    var result;
    if (typeof x == "number" && typeof y == "number") {
        result = x + y;
    }
    else {
        result = x + y;
    }
    return result;
}
var result1 = add(10, 20);
var result2 = add("hiii", " welcome to typescript");
console.log(result1);
console.log(result2);
