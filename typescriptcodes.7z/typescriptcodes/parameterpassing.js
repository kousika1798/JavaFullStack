function addition(a, b) {
    return a + b;
}
var sum = addition(50, 80);
var sum1 = addition("hiii", 50);
var sum2 = addition('c', 'h');
function addition2(x, y) {
    return x + y;
}
var sum3 = addition2(5, 20);
console.log(sum3);
console.log(sum);
console.log(sum1);
console.log(sum2);
//var sum4=addition2("hii",10);------other data type values in typescripting
