var a:number=12;
var b:number;
var c:String;
var d:boolean;
var e=undefined;
var f=null;

a=123;
b=20;
c="welcome";
d=false;
e="name";
console.log(a+b);