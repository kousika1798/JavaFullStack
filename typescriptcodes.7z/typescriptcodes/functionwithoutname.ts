function add(a:number,b:number,c?)
{
    return a+b+c;
}
var sum1=add(2,5,7);
var sum2=add(5,8);
let sum=function (x,y,z,u?:number)
{
    return x+y+z+u;
}
sum(15,20,189);

let sum4=(x:number,y:number,z:number)=>x+y+z;
sum4(10,20,15);
console.log(sum1);
console.log(sum2);
console.log(sum);
console.log(sum4);
let sum5=(x:number,y:number)=>{return x+y};
sum5(10,20);
console.log(sum5);