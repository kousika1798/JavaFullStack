let fname:string="IBM";
let site:string='www.ibm.com';
let string1="Hello my name is "+fname+"site is "+site;
console.log(string1);
let string2=`my name is ${fname} and site is ${site} `;
console.log(string2); 