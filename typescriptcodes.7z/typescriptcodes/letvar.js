function kousi() {
    var a;
    a = 50;
    if (a >= 25) {
        var a1 = 30;
        var b = 60;
        console.log(a);
        console.log(b);
        console.log(a1);
    }
    console.log(a);
    console.log(b);
    // console.log(a1);-----let keyword is block level
    // var keyword is in function level
}
kousi();
