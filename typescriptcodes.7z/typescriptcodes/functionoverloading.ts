function add(x:string,y:string):string;
function add(x:number,y:number):number;

function add(x:any,y:any)
{
    let result:any;
    if(typeof x=="number"&&typeof y=="number")
    {
        result=x+y;
    }
    else{
        result=x+y;
    }
    return result;
}
let result1=add(10,20);
let result2=add("hiii"," welcome to typescript");
console.log(result1);
console.log(result2);